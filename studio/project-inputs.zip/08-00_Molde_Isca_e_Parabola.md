# FervoTrama v2 · Molde "Isca e Parábola"

Serve para todas as novelas novas e para reescrever as antigas.

## A ideia em uma frase
O público entra por um **mistério humano** e só no fim percebe que viveu uma **parábola de Jesus**. Primeiro ele sente, depois reconhece.

## As 8 regras

1. **Gancho de 3 s = pergunta impossível de ignorar.** Sobre gente comum, sem nenhuma palavra de fé. Exemplos: "Alguém quitou minha dívida. Eu não sei quem." / "Essa letra é da Marta. E a Marta morreu faz dois anos."
2. **Promessa de resposta nos primeiros 10 s.** O público precisa sentir que a revelação vem.
3. **Re-gancho a cada 2 clipes (20 s).** Uma informação nova que muda a pergunta. Nunca dois clipes seguidos só de conversa.
4. **Um soco de emoção por episódio**, no clipe 7 ou 8 (vergonha pública, perdão inesperado, verdade dita em voz alta). Depois, 1 clipe de respiro.
5. **Cliffhanger = pergunta nova + objeto na tela + corte seco.** Nunca resolva a pergunta do gancho antes do penúltimo episódio.
6. **Palavras de fé só a partir do episódio 3** (nas novelas "isca"). Antes disso, a fé aparece como gesto: alguém agradece antes de comer, um livro sublinhado, uma ausência que dói.
7. **A trama É a parábola.** Escolha uma ação de Jesus (pagar, perdoar antes de pedir, carregar a culpa, buscar o que faltava) e deixe a história fazer isso. Primeiro mostre, depois nomeie, **em um único clipe**, na voz de um personagem. Sem sermão.
8. **Assinatura: "A Palavra".** Último clipe da temporada termina com uma frase de Jesus, palavra por palavra, com referência (3 s de tela). Respeita a sua regra: Jesus só fala o que está nos Evangelhos.

## Estrutura de um episódio (≈100 s, 10 clipes)

| Clipes | Função |
|---|---|
| C01 | Gancho (pergunta ou frase que acusa) |
| C02–C03 | Mundo e problema, com um segundo mistério pequeno |
| C04–C05 | Primeira pista / primeira reviravolta |
| C06 | Respiro curto (humor leve em personagem humano) |
| C07–C08 | Soco de emoção |
| C09 | Informação que muda tudo |
| C10 | Cliffhanger |

Falas de 10 s: **no máximo ~20 palavras.** Se o gerador recusar um clipe, gere o "Plano B": mesma cena sem fala, com a frase como legenda ou áudio na edição.

## O que fazer com as 6 novelas atuais

| Novela | Decisão |
|---|---|
| O Caderno da Vó Noêmia | Manter como série "casa" (para quem já crê). Reeditar o E01: abrir pela frase de 1998, sem mostrar o caderno de orações nos primeiros 3 s. |
| A Foto dos Ausentes | Manter e **expandir para 5–6 episódios**. Hoje tem só 2 e é a melhor emoção do pacote. Incluir a cruz. |
| Sem o Meu Nome | **Reescrita completa** (pasta 03). |
| A Plateia de Uma Pessoa Só | Arquivar ou simplificar muito. Técnica demais para um público frio. |
| O Homem que Ficou na Linha | Reaproveitar a imagem ("o homem que ficou na linha") dentro de uma ideia nova, "Faltou Um" (ver Banco de Ideias). |
| A Foto de Domingo | Encurtar para 4 episódios. O prato no degrau e a cena de Pedro são ótimos. |

## Honestidade
Ninguém consegue garantir viralização. O molde aumenta as chances. Poste os 3 primeiros episódios de duas novelas novas e compare **retenção aos 3 s** e **% assistido**. A que reter mais vira a principal.
