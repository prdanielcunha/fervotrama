# FervoTrama · Tendências e plano de postagem (23/11/2026)

## 1. O que a pesquisa mostrou (resumo honesto)

- **Novela vertical virou formato oficial.** TikTok lançou o PineDrama (app só de novelas verticais) e testa feed de minidramas; YouTube lançou "Shorts em série" para organizar vídeo vertical em capítulos; Netflix, Globo (GloboPop) e Kwai também entraram. Quem posta em **série numerada** está alinhado com o que as plataformas estão empurrando.
- **Série vence vídeo solto.** Kwai e outros apontam que narrativa seriada cria vínculo e retenção. Gancho nos 3 primeiros segundos continua sendo a regra número 1.
- **Fé + IA realista já provou audiência.** Perfis de histórias bíblicas feitas com IA somaram dezenas de milhões de views (ex.: o "Vlog Bíblico", no Brasil). Também há **rejeição**: parte do público cristão critica Jesus gerado por IA e há muito "lixo de IA" (as novelinhas de fruta). Por isso, a nossa vantagem é: **gente comum, drama real, cruz no final, e Jesus falando só com palavras dos Evangelhos**.
- **Risco a evitar:** não mostrar o rosto de Jesus gerado por IA. Ele aparece como **palavra na tela** (assinatura "A Palavra").

Não existe garantia de viralização. O plano abaixo maximiza as chances e permite medir.

## 2. Plano para hoje

1. **Poste E01, E02 e E03 de "Sem o Meu Nome"** (em sequência, com 1 a 2 horas de intervalo), porque quem curte o E01 precisa de continuidade logo. Horário de pico no Brasil costuma ser à noite, mas confira o seu Analytics.
2. **Ative o rótulo "conteúdo feito com IA"** em todos.
3. **Metas para medir:** retenção aos 3 s (meta: acima de 70%) e % assistido até o fim. Se E01 passar disso, solte E04 e E05 amanhã.
4. **Fixe um comentário** em cada episódio: "Parte 2 no perfil 👆" (e o link/lista da série).
5. **Legenda curta, que gere comentário** (ver cada episódio).

## 3. Texto fixo na tela (padrão de toda a série)

- Topo, 3 primeiros segundos: **a frase-gancho em letras grandes**.
- Canto: "SEM O MEU NOME · Ep. 1/5".
- Último clipe do E05: **A Palavra** (referência bíblica, 3 s).

## 4. Próximas novelas (já na fila, mesmo molde)

| Título | Parábola | Gancho de 3 s |
|---|---|---|
| **Faltou Um** | A ovelha perdida | "Contei os convidados três vezes. Faltou um. E ninguém sentiu." |
| **A Mesa Que Ficou Posta** | O filho pródigo (para quem nunca conheceu o Pai) | "Todo domingo ele põe um prato a mais. Nunca me disse para quem." |
| **A Foto dos Ausentes** (expandir para 5 eps) | O bom pastor + a cruz | "De quem é essa mão na foto de família?" |

Diga qual vem depois e eu escrevo completa.
